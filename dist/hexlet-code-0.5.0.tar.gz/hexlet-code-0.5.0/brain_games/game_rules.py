def game_rules():
    print('Answer "yes" if the number is even, otherwise answer "no".')


if __name__ == '__game_rules__':
    game_rules()
